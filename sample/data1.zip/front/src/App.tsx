import { useState ,useEffect} from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import Keycloak from 'keycloak-js';
import KeycloakAuthorization from "./keycloak-authz"

function decodeToken(token:string) {
  const [header, payload] = token.split(".");
  console.log(header)
  if (typeof payload !== "string") {
      throw new Error("Unable to decode token, payload not found.");
  }

  let decoded;

  try {
      decoded = base64UrlDecode(payload);
  } catch (error) {
    console.log(error)
      throw new Error("Unable to decode token, payload is not a valid Base64URL value.");
  }

  try {
      return JSON.parse(decoded);
  } catch (error) {
    console.log(error)
      throw new Error("Unable to decode token, payload is not a valid JSON value.");
  }
}

/**
* @param {string} input
*/
function base64UrlDecode(input:string) {
  let output = input
      .replaceAll("-", "+")
      .replaceAll("_", "/");

  switch (output.length % 4) {
      case 0:
          break;
      case 2:
          output += "==";
          break;
      case 3:
          output += "=";
          break;
      default:
          throw new Error("Input is not of the correct length.");
  }

  try {
      return b64DecodeUnicode(output);
  } catch (error) {
      console.log(error)
      return atob(output);
  }
}

/**
* @param {string} input
*/
function b64DecodeUnicode(input:string) {
  return decodeURIComponent(atob(input).replace(/(.)/g, (m, p) => {
      let code = p.charCodeAt(0).toString(16).toUpperCase();

      if (code.length < 2) {
          code = "0" + code;
      }

      return "%" + code;
  }));
}


function AllowdEntity(props:any){

  if(props.permissions.length > 0 ){
    return (        
    <div >
        You can access <span style={{color: "red",fontSize: 30}}>{props.permissions[0].rsname}</span>

    </div>)
  }
  return <div></div>

}
interface KeycloakState {
  keycloak: Keycloak | null;
  authenticated: boolean;
  rpt: string;
}

const keycloakConfig = {
  url: "https://kc.local.dev/",
  clientId: "app1",
  realm: "master",
};


function App() {
  const keycloak = new Keycloak(keycloakConfig);
  const [keycloakState, setKeycloakState] = useState<KeycloakState>({
    keycloak: null,
    authenticated: false,
    rpt: "",
  });

  const [count, setCount] = useState(0);

  useEffect(() => {
    if(!keycloak.authenticated){
      keycloak
      .init({ onLoad: 'login-required' })  //check-sso
      .then((authenticated) => {
        setKeycloakState({ keycloak: keycloak, authenticated: authenticated,rpt:"" });

        const authorization = new KeycloakAuthorization(keycloak);
        const req = authorization.entitlement('resource-backend');
        
        setTimeout(() => {
          req.then(function(rpt){
            //console.log(rpt);
            setKeycloakState({ keycloak: keycloak, authenticated: authenticated,rpt:rpt});
          },function(){
            console.log("onDeny")
          },function(){
            console.log("onError")
          });
      }, 300);

      })
      .catch((e) => {
        console.error(e);
      });
    }

  },[]);

  let permissions = []
  if(keycloakState.rpt.length >  0){
    console.log("rpt",keycloakState.rpt);
    const rptParsed = decodeToken(keycloakState.rpt);
    console.log("parse",rptParsed);
    permissions = rptParsed.authorization.permissions;
    console.log("parse",rptParsed.authorization.permissions);
  }

    return (
      <div>

      { keycloakState.authenticated && (
        <div>
          <div>
          <a href="https://vitejs.dev" target="_blank" rel="noopener">
            <img src={viteLogo} className="logo" alt="Vite logo" />
          </a>
          <a href="https://react.dev" target="_blank" rel="noopener">
            <img src={reactLogo} className="logo react" alt="React logo" />
          </a>
          </div>
          <h1>Vite + React</h1>
          <div className="card">
            <button onClick={() => setCount((count) => count + 1)}>count is {count}</button>
            <AllowdEntity permissions={permissions}></AllowdEntity>
            <p>
              Edit <code>src/App.tsx</code> and save to test HMR 
            </p>
          </div>

          <p className="read-the-docs">Click on the Vite and React logos to learn more</p>
        </div>
      ) 
      }
  


  </div>
  );
  
}

export default App;
