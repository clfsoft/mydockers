package com.example.resource_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class ResourceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourceApiApplication.class, args);
	}

	@GetMapping("/entity1")
	public String get1(@AuthenticationPrincipal Jwt jwt) {
		return String.format("get entity1, %s!", jwt.getClaimAsString("preferred_username"));
	}


	@GetMapping("/entity2")
	public String get2(@AuthenticationPrincipal Jwt jwt) {
		return String.format("get entity2, %s!", jwt.getClaimAsString("preferred_username"));
	}

	@PostMapping("/entity2")
	public String post(@AuthenticationPrincipal Jwt jwt) {
		return String.format("post entity, %s!", jwt.getClaimAsString("preferred_username"));
	}
}
