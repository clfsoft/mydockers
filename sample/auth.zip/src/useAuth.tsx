import { createContext, ReactNode, useContext, useState, } from "react";

import {KeycloakState} from "./Util"

interface IAuth {
  keycloakState: KeycloakState|null,
  setKeycloakState: (s:KeycloakState)=>void

}

export const AuthContext =createContext<IAuth>({keycloakState:null,setKeycloakState:()=>{}});


export const AuthProvider = ({children}:{children:ReactNode}) =>{
  const [keycloakState, setKeycloakState] = useState<KeycloakState>({
    keycloak: null,
    authenticated: false,
    rpt: "",
    authToken: null
  });

  return (
    <AuthContext.Provider value={{keycloakState,setKeycloakState}}>
    {children}
    </AuthContext.Provider>
  )

}

export  const useAuth =  () =>useContext(AuthContext)
