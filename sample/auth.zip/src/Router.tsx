import { createBrowserRouter ,createRoutesFromElements,Route} from "react-router-dom";
import { Entity1Page,Entity2Page } from "./Page.tsx";
import {AuthLoader} from "./AuthRouter.tsx"
import {  RouterProvider } from "react-router-dom";

import App from "./App.tsx";
import {useAuth} from "./useAuth"
export function Router(){
  const {keycloakState} = useAuth();


  const routers =  createBrowserRouter(

    createRoutesFromElements(
      <Route >
      <Route path="/" element={<App/>}></Route>
      <Route path="entity1" element={<Entity1Page/>}  loader={AuthLoader(keycloakState,"entity1")}/>
      <Route path="entity2" element={<Entity2Page/>}  loader={AuthLoader(keycloakState,"entity2")}/>
      <Route path="entity3" element={<Entity2Page/>}  loader={AuthLoader(keycloakState,"entity3")}/>
      </Route>
    )
  );

  return <RouterProvider router={routers} />;
}


