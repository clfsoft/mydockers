
import Keycloak from 'keycloak-js';
export interface AuthorizationToken {

    authorization: {permissions: Permission[]}

}
export interface Permission {
    rsname: string
}

export interface KeycloakState {
  keycloak: Keycloak | null;
  authenticated: boolean;
  rpt: string;
  authToken: AuthorizationToken|null;
}

export function decodeToken(token: string):AuthorizationToken {
  const [header, payload] = token.split(".");
  console.log(header);
  if (typeof payload !== "string") {
    throw new Error("Unable to decode token, payload not found.");
  }

  let decoded;

  try {
    decoded = base64UrlDecode(payload);
  } catch (error) {
    console.log(error);
    throw new Error("Unable to decode token, payload is not a valid Base64URL value.");
  }

  try {
    return JSON.parse(decoded);
  } catch (error) {
    console.log(error);
    throw new Error("Unable to decode token, payload is not a valid JSON value.");
  }
}

/**
 * @param {string} input
 */
export function base64UrlDecode(input: string) {
  let output = input.replaceAll("-", "+").replaceAll("_", "/");

  switch (output.length % 4) {
    case 0:
      break;
    case 2:
      output += "==";
      break;
    case 3:
      output += "=";
      break;
    default:
      throw new Error("Input is not of the correct length.");
  }

  try {
    return b64DecodeUnicode(output);
  } catch (error) {
    console.log(error);
    return atob(output);
  }
}

/**
 * @param {string} input
 */
export function b64DecodeUnicode(input: string) {
  return decodeURIComponent(
    atob(input).replace(/(.)/g, (m, p) => {
      let code = p.charCodeAt(0).toString(16).toUpperCase();

      if (code.length < 2) {
        code = "0" + code;
      }

      return "%" + code;
    })
  );
}
