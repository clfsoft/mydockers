


export const NotAuthroizePage = () => (
  <div>
    <h1>権限が足りない。</h1>
  </div>
);
