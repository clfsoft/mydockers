import {AuthorizationToken} from "./Util"
import { Link } from "react-router-dom";
export function AuthLink({to,text,grant,auth}:{to:string,text:string, grant:string, auth:AuthorizationToken|null}){


  if(auth !==null && grant === auth.authorization.permissions[0].rsname){
    return <Link to={to} >{text}</Link>
  }


  return <div>{text} not allowed</div>


}