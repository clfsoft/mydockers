import { useState ,useEffect} from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import Keycloak from 'keycloak-js';
import KeycloakAuthorization from "./keycloak-authz"
import { AuthLink } from "./AuthLink";
import { decodeToken } from "./Util";
import { useAuth } from "./useAuth";


const keycloakConfig = {
  url: "https://kc.local.dev/",
  clientId: "app1",
  realm: "master",
};


function App() {
  const keycloak = new Keycloak(keycloakConfig);
  const {keycloakState, setKeycloakState} = useAuth();

  const [count, setCount] = useState(0);

  useEffect(() => {
    if(!keycloak.authenticated){
      keycloak
      .init({ onLoad: 'login-required' })  //check-sso
      .then((authenticated) => {
        setKeycloakState({ keycloak: keycloak, authenticated: authenticated,rpt:"" ,authToken:null});

        const authorization = new KeycloakAuthorization(keycloak);
        const req = authorization.entitlement('resource-backend');
        
        setTimeout(() => {
          req.then(function(rpt){
            
            const authorizationToken = decodeToken(rpt);
            console.log("authorizationToken",authorizationToken);
            setKeycloakState({ keycloak: keycloak, authenticated: authenticated,rpt:rpt,authToken:authorizationToken});
          },function(){
            console.log("onDeny")
          },function(){
            console.log("onError")
          });
      }, 300);

      })
      .catch((e) => {
        console.error(e);
      });
    }

  },[]);
  

    return (
      <div>

      {keycloakState !== null && keycloakState.authenticated && (
        <div>
          <div>
          <a href="https://vitejs.dev" target="_blank" rel="noopener">
            <img src={viteLogo} className="logo" alt="Vite logo" />
          </a>
          <a href="https://react.dev" target="_blank" rel="noopener">
            <img src={reactLogo} className="logo react" alt="React logo" />
          </a>
          </div>
          <h1>
          <AuthLink to="/entity1" text="entity1" grant="entity1" auth={keycloakState.authToken}/>
          <br/>
          <AuthLink to="/entity2" text="entity2" grant="entity2" auth={keycloakState.authToken}/>
          <br/>
          <AuthLink to="/entity3" text="entity2-page-load-error" grant="entity2" auth={keycloakState.authToken}/>
          </h1>
          <div className="card">
            <button onClick={() => setCount((count) => count + 1)}>count is {count}</button>
            <p>
              Edit <code>src/App.tsx</code> and save to test HMR 
            </p>
          </div>

          <p className="read-the-docs">Click on the Vite and React logos to learn more</p>
        </div>
      ) 
      }
  


  </div>
  );
  
}

export default App;
