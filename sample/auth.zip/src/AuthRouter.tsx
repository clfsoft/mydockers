
//import { ReactNode } from "react";
import { KeycloakState } from "./Util";

//import {Route} from "react-router-dom";

// export function AuthRouter({path,element,keycloakState}:{path:string,element:ReactNode,keycloakState:KeycloakState|null}):ReactNode{

// return <Route path={path} element={element}  loader={AuthLoader(keycloakState)}/>

// }


export  function AuthLoader(keycloakState:KeycloakState|null, grant:string){

  console.log("AuthLoader:",keycloakState?.authToken)
  return  () =>{
    //TODO if not authed require auth
    // 
    console.log("request-new-data:", "TODO")
    if(keycloakState != null && keycloakState.authenticated && keycloakState.authToken?.authorization.permissions[0].rsname === grant){

      return {"auth":keycloakState.authToken}
    }
    throw new Response("Not Allowed", { status: 401 });
  };
}