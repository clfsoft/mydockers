//import { StrictMode } from "react";
import { createRoot, } from "react-dom/client";
import {Router} from "./Router"



import "./index.css";
import { AuthProvider  } from "./useAuth";

createRoot(document.getElementById("root")!).render(
  <AuthProvider>
  <Router/>
  </AuthProvider>
);
