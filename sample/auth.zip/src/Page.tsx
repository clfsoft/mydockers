import {
  useLoaderData,
} from "react-router-dom";

import {AuthorizationToken} from "./Util"

export  function Entity1Page() {
  const {auth}  = useLoaderData() as {auth:AuthorizationToken};
  return (
  <div>
    <h1>This is the Entity1 ==  {auth.authorization.permissions[0].rsname}</h1>
  </div>
  )

};


export  function Entity2Page() {
  const {auth}  = useLoaderData() as {auth:AuthorizationToken};
  return (
  <div>
    <h1>This is the Entity2 ===  {auth.authorization.permissions[0].rsname}</h1>
  </div>
  )

};